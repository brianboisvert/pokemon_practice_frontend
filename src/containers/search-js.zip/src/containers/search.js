import React from 'react';
import Select from 'react-select';
import makeAnimated from 'react-select/lib/animated';

class Search extends React.Component {

  state = {
    selectedTypes: []
  }


  // onSubmit(event) {
  //   event.preventDefault();
  //   console.log(this.props);
  //   // this.props.selectedTypes(this.state.selectedTypes);
  // }

  handleChange(value) {
    this.setState({
      selectedTypes: value.map(type => type["values"])
    })
  }

  render() {
    // console.log(this.props);
    const pokeTypes = this.props.types.flat(2).map(type => type["type"]["name"]).sort()
    let uniqueTypes = [...new Set(pokeTypes)]
    let options = uniqueTypes.map((type) => {
      return ({ value: type, label: type });
    })

    return(
      <form onSubmit={this.props.selectedTypes(this.state.selectedTypes)}>
        <Select
          options={options}
          closeMenuOnSelect={false}
          components={makeAnimated()}
          isMulti
          onChange={this.handleChange.bind(this)}
         />
        <input type="submit" value="Submit" />
      </form>
    )
  }
}

export default Search;
